import tkinter as tk 
from tkinter import ttk 
from model.tostada_dao import crear_tabla, borrar_tabla
from model.tostada_dao import Materia_prima, guardar,listar,editar, eliminar
from tkinter import messagebox


def barra_menu(root):
    barra_menu = tk.Menu(root)
    root.config(menu=barra_menu, width=700, height= 700)
     
    #menu de inicio
    #tearoff es para que no haya lineas 
    menu_inicio = tk.Menu(barra_menu)
    barra_menu.add_cascade(label='Inicio', menu = menu_inicio)

    #nombre del comando 
    #estamos añadiendo los comandos que creamos en tostada_dao para la base de datos
    menu_inicio.add_command(label='Crear registro en DB', command=crear_tabla)
    menu_inicio.add_command(label='Eliminar registro en DB', command=borrar_tabla)
    menu_inicio.add_command(label='Salir',command = root.destroy)

    barra_menu.add_cascade(label='Producto',menu = menu_inicio)
    barra_menu.add_cascade(label='Ventas',menu = menu_inicio)
    barra_menu.add_cascade(label='Clientes',menu = menu_inicio)
    barra_menu.add_cascade(label='Empleados',menu = menu_inicio)
    barra_menu.add_cascade(label='Materia prima',menu = menu_inicio)
    barra_menu.add_cascade(label='Proveedor',menu = menu_inicio)
    
    

class Frame(tk.Frame):
    def __init__(self, root = None):
        super().__init__(root, width=780, height=500) #Heredar el constructor 
        self.root = root #lo que voy a recibir 
        self.pack()  #empaquetamos 
        self.config(bg='white') #tamaño y color 

        self.id_materia_prima = None

        self.campos_materia_prima()
        self.desabilitar_campos()
        self.tabla_materia_prima()

    #para agregar los atributos
    def campos_materia_prima(self):
       
        self.label_nombre=tk.Label(self, text = 'Nombre')
        self.label_nombre.config(font =('Arial',12,'bold'))
        self.label_nombre.grid(row=0,column=0, padx=10, pady=10)
       

        #descripción 
        self.label_Descripcion=tk.Label(self, text = 'Descripción')
        self.label_Descripcion.config(font =('Arial',12,'bold'))
        self.label_Descripcion.grid(row=4,column=0,padx=10, pady=10)

        #para los campos de entrada 
        #este es para que se limpien los datos cuando presionemos cancelar o guardar 
        self.mi_nombre = tk.StringVar()
        #nombre
        self.entry_nombre = tk.Entry(self, textvariable=self.mi_nombre)
        self.entry_nombre.config(width=50,font =('Arial',12,'bold'))
        self.entry_nombre.grid(row=0, column=1,padx=10, pady=10, columnspan=2)

        #descripción 
        self.mi_descripcion = tk.StringVar()
        self.entry_Descripcion = tk.Entry(self,textvariable=self.mi_descripcion)
        self.entry_Descripcion.config(width=50,font =('Arial',12,'bold'))
        self.entry_Descripcion.grid(row=4, column=1,padx=10, pady=10,columnspan=2)

        #BOTONES
        #grid es para la posicion
        #TENEMOS QUE CAMBIAR los colores 
        #AGREGAR
        self.boton_agregar = tk.Button(self, text='Agregar',command=self.habilitar_campos)
        self.boton_agregar.config(width = 20, font = ('Arial',12,'bold'),
            fg = '#000000', background= '#25699A',
            cursor = 'hand2')
        self.boton_agregar.grid(row=5,column=0,padx=10, pady=10)

        #GUARDAR
        self.boton_guardar = tk.Button(self, text='Guardar', command= self.guardar_datos)
        self.boton_guardar.config(width = 20, font = ('Arial',12,'bold'),
                                fg = '#000000', background= '#25699A',
                                cursor = 'hand2')
        self.boton_guardar.grid(row=5,column=1,padx=10, pady=10)

        #
        self.boton_cancelar = tk.Button(self, text='Cancelar', command=self.desabilitar_campos)
        self.boton_cancelar.config(width = 20, font = ('Arial',12,'bold'),
                                fg = '#000000', background= '#25699A',
                                cursor = 'hand2')
        self.boton_cancelar.grid(row=5,column=2,padx=10, pady=10)

       
    def habilitar_campos(self):
        #habilitar entradas
        self.entry_nombre.config(state='normal')
    
        self.entry_Descripcion.config(state='normal')
        #habilitar botones
        self.boton_guardar.config(state='normal')
        self.boton_cancelar.config(state='normal')

    def desabilitar_campos(self):
        #para enviar campos vacios
        #set es para enviar datos
        self.id_materia_prima= None
        self.mi_nombre.set('')
       
        self.mi_descripcion.set('')
        #desabilitar entradas 
        self.entry_nombre.config(state='disabled')
       
        self.entry_Descripcion.config(state='disabled')
        #desabilitar botones
        self.boton_guardar.config(state='disabled')
        self.boton_cancelar.config(state='disabled')
    #limpiar los campos y habilitarlos 
    def guardar_datos(self):
        #para recuperar los datos que ingresamos en los campos
        materia_prima = Materia_prima(
            self.mi_nombre.get(),
            self.mi_descripcion.get(),  
        )
        #cuando queremos editar 
        if self.id_materia_prima == None:
            guardar(materia_prima)
        else:
            editar(materia_prima, self.id_materia_prima)
        
        #para que se actualice la tabla cada que ingresamos un nuevo registro
        #y se muestra en pantalla
        self.tabla_materia_prima()
        self.desabilitar_campos()


    def tabla_materia_prima(self):
       
        self.lista_materia_prima = listar()
       
        self.lista_materia_prima.reverse()

        #NOTA: NO SE PORQUE SE ESTAN CREANDO UNA COLUMNA DE MAS EN LA TABLA

        #estamos creando el objeto de tabla para ver los registros que ponemos en los campos
        self.tabla = ttk.Treeview(self,
            column = ('Nombre','Descripción'))
        self.tabla.grid(row=6,column=0, columnspan=3,sticky='nse')

        #Scrollbar para poder visualizar todos los registros
        self.scroll = tk.Scrollbar(self,
            orient = 'vertical', command= self.tabla.yview)
    
        self.scroll.grid(row=6, column=3, sticky='nse')
        self.tabla.configure(yscrollcommand=self.scroll.set)

        #para los encabezados 
        self.tabla.heading('#0',text='ID')
        self.tabla.heading('#1',text='Nombre')
        self.tabla.heading('#2',text='Descripción')

       
        for p in self.lista_materia_prima:
            self.tabla.insert('',0, text=p[0], 
                values= (p[1],p[2]))
        
        #BOTONES DE EDITAR Y ELIMINAR
        #BOTON EDITAR
        self.boton_editar = tk.Button(self, text='Editar', command = self.editar_datos)
        self.boton_editar.config(width = 20, font = ('Arial',12,'bold'),
            fg = '#000000', background= '#25699A',
            cursor = 'hand2')
        self.boton_editar.grid(row=7,column=0,padx=10, pady=10)

        #BOTON ELIMINAR
        self.boton_eliminar = tk.Button(self, text='Eliminar', command= self.eliminar_datos)
        self.boton_eliminar.config(width = 20, font = ('Arial',12,'bold'),
                                fg = '#000000', background= '#25699A',
                                cursor = 'hand2')
        self.boton_eliminar.grid(row=7,column=1,padx=10, pady=10)

    def editar_datos(self):
        try:
            self.id_materia_prima = self.tabla.item(self.tabla.selection())['text']
            self.nombre = self.tabla.item(self.tabla.selection())['values'][0]
            self.descripcion = self.tabla.item(self.tabla.selection())['values'][1]
            
        
            self.habilitar_campos()

            #mostrar los datos que queremos para cambiarlos
            self.entry_nombre.insert(0,self.nombre)
            self.entry_Descripcion.insert(0,self.descripcion)
            
            
        except:
            titulo = 'Edición de datos'
            mensaje = 'No ha seleccionado ningún registro'
            messagebox.showerror(titulo, mensaje)

    def eliminar_datos(self):
        try:
            self.id_materia_prima = self.tabla.item(self.tabla.selection())['text']
            eliminar(self.id_materia_prima)

            self.tabla_materia_prima()
         
            self.id_materia_prima = None
        except:
            titulo = 'Eliminar un registro'
            mensaje = 'No ha seleccionado ningún registro'
            messagebox.showerror(titulo, mensaje)
