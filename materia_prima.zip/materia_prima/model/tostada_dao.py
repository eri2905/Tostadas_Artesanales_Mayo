from .conexion_db import ConexionDB
from tkinter import messagebox

def crear_tabla():
    #realizar la conexion a la base de datos
    conexion = ConexionDB()

    sql = '''
    CREATE TABLE materia_prima(
    
    id INTEGER,
    nombre VARCHAR(50),
    descripcion TEXT, 
    PRIMARY KEY(id AUTOINCREMENT)
    )'''
    try: 
        #para ejecutar el sql 
        conexion.cursor.execute(sql)
        #cerramos 
        conexion.cerrar()
        titulo = 'Crear Registro'
        mensaje = 'Se creo la tabla en la base de datos'
        #mostrar que se pudo hacer la tabla 
        messagebox.showinfo(titulo,mensaje)
    except:
        conexion.cerrar()
        titulo = 'Crear Registro'
        mensaje = 'La tabla ya está creada'
        #mostrar que se pudo hacer la tabla 
        messagebox.showwarning(titulo,mensaje)
        

def borrar_tabla():
    conexion = ConexionDB()

    sql = 'DROP TABLE materia_prima'
    try: 
        conexion.cursor.execute(sql)
        conexion.cerrar()
        titulo = 'Borrar Registro'
        mensaje = 'La tabla de la base de dados se borró con éxito'
        messagebox.showwarning(titulo,mensaje)
    except:
        titulo = 'Borrar Registro'
        mensaje = 'No hay tabla para borrar'
        messagebox.showerror(titulo,mensaje)

class Materia_prima:
    #constructor
    def __init__(self, nombre,descripcion):
        self.id_materia_prima = None
        self.nombre = nombre
        self.descripcion = descripcion
    #estado del objeto 

    def __str__(self):
        return f'Materia_prima[{self.nombre},{self.descripcion}]'
    
#ingresar o guardar datos
def guardar(materia_prima):
    #para guardar en la base de datos, conectamos
    conexion = ConexionDB()

    sql = f"""INSERT INTO materia_prima(nombre,descripcion)
    VALUES ('{materia_prima.nombre}','{materia_prima.descripcion}')"""

    try:
        conexion.cursor.execute(sql)
        conexion.cerrar()
    except:
        titulo = 'Conexión al registro'
        mensaje = 'La tabla de materia prima no está creado en la base de datos'
        messagebox.showerror(titulo,mensaje)

def listar():
    conexion = ConexionDB()

    #recuperar todos los registro de la tabla

    lista_materia_prima = []
    sql = 'SELECT * FROM materia_prima'

    try:
        conexion.cursor.execute(sql)
        #recuperamos toda informacion con fetchall
        lista_materia_prima = conexion.cursor.fetchall()
        conexion.cerrar()
    #si la tabla no existe
    except:
        titulo = 'Conexión al registro'
        mensaje = 'Crea la tabla en la base de datos'
        messagebox.showwarning(titulo,mensaje)

    return lista_materia_prima

def editar(materia_prima , id_materia_prima):
    conexion = ConexionDB()

    sql = f"""UPDATE materia_prima
    SET nombre = '{materia_prima.nombre}',
        descripcion = '{materia_prima.descripcion}'
    WHERE id = '{id_materia_prima}'"""

    try:
        conexion.cursor.execute(sql)
        conexion.cerrar()

    except:
        titulo = 'Edición de datos'
        mensaje = 'No se ha podido editar este registro'
        messagebox.showerror(titulo,mensaje)

def eliminar(id_materia_prima):
    conexion = ConexionDB()
    sql = f'DELETE FROM materia_prima WHERE id = {id_materia_prima}'

    try:
        conexion.cursor.execute(sql)
        conexion.cerrar()

    except:
        titulo = 'Eliminar Datos'
        mensaje = 'No se pudo eliminar el registro'
        messagebox.showerror(titulo,mensaje)

        
